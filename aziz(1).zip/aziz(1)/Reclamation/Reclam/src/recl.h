#include<gtk/gtk.h>
typedef struct
{
int jour;
int mois;
int annee;
}DATE;


typedef struct
{
    
    char identifiant[20];
    char nom[15];
    char type[20];
    char choix[20];
    DATE date;
    char reclame[20];
    char etat[20];
    
}reclamation;

void ajouterreclamation(reclamation a);
void supprimerreclamation(char identifiant []);
void affichagereclamation(GtkWidget *liste);
void modifierreclamation(reclamation a);
int remplirtab (reclamation tab[],int nb);
int rechercherreclamation(char identifiant[]);
void affichagereclamationrechercher(GtkWidget *liste);
int plusreclame();










