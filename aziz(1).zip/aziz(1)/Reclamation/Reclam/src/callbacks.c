#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include "recl.h"
#include "callbacks.h"
#include "interface.h"
#include "support.h"

int x,y;

int z,l;

void
on_retour_clicked                      (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_radiobutton1_etu_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{x=1;}
}


void
on_radiobutton1_enseig_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{x=0;}
}


void
on_checkbutton1_urg_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{y=1;}
}


void
on_button1_ajout_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
reclamation a;
GtkWidget *windowajout, *windowaffich,*type,*id,*nom,*reclame,*jour,*mois,*annee,*choix,*etat;
windowajout=create_fenetre_ajout();
windowaffich=create_fenetre_afficher();
id = lookup_widget(button,"entry1_id");
nom = lookup_widget(button,"entry1_nom");
type=lookup_widget(button,"comboboxentry1_type");
jour = lookup_widget(button,"spinbutton1_jour");
mois = lookup_widget(button,"spinbutton1_mois");
annee = lookup_widget(button,"spinbutton1_annee");
reclame = lookup_widget(button,"entry1_recl");
strcpy(a.identifiant,gtk_entry_get_text(GTK_ENTRY(id)));
strcpy(a.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(a.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(type)));
a.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (jour));
a.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (mois));
a.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (annee));
strcpy(a.reclame,gtk_entry_get_text(GTK_ENTRY(reclame)));
if(x==1 )
{strcpy(a.choix,"Etudiant");} 
else
{strcpy(a.choix,"Enseignant");}
if(y==1)
{strcpy(a.etat,"urgent");} 
else
{strcpy(a.etat,"simple");}
ajouterreclamation(a);
x=0;
y=0;


windowajout=lookup_widget(button,"fenetre_ajout");
gtk_widget_destroy(windowajout);
windowaffich=create_fenetre_afficher();
gtk_widget_show(windowaffich);
}


void
on_checkbutton1_info_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{y=0;}
}

void
on_button0_ajtt_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowajout ;
windowajout=create_fenetre_ajout();
gtk_widget_show (windowajout);
}


void
on_button0_supp_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowsup;
windowsup=create_window_sup();
gtk_widget_show (windowsup);
}

void
on_radiobutton2_etu_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{l=1;}
}


void
on_radiobutton2_ens_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{l=0;}
}


void
on_checkbutton2_urg_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{z=1;}
}


void
on_checkbutton2_sip_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{z=0;}
}


void
on_button2_mod_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
reclamation a1;
GtkWidget *windowmodif, *windowaffich,*type1,*id1,*nom1,*reclame1,*jour1,*mois1,*annee1,*choix1,*etat1;
windowmodif=create_window_modification();
windowaffich=create_fenetre_afficher();
id1 = lookup_widget(button,"entry2_id");
nom1 = lookup_widget(button,"entry2_nom");
type1=lookup_widget(button,"comboboxentry2");
jour1 = lookup_widget(button,"spinbutton2_jour");
mois1 = lookup_widget(button,"spinbutton2_mois");
annee1 = lookup_widget(button,"spinbutton2_annee");
reclame1 = lookup_widget(button,"entry2_recl");
strcpy(a1.identifiant,gtk_entry_get_text(GTK_ENTRY(id1)));
strcpy(a1.nom,gtk_entry_get_text(GTK_ENTRY(nom1)));
strcpy(a1.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(type1)));
a1.date.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (jour1));
a1.date.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (mois1));
a1.date.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (annee1));
strcpy(a1.reclame,gtk_entry_get_text(GTK_ENTRY(reclame1)));
if(l==1 )
{strcpy(a1.choix,"Etudiant");} 
else
{strcpy(a1.choix,"Enseignant");}
if(z==1)
{strcpy(a1.etat,"urgent");} 
else
{strcpy(a1.etat,"simple");}
modifierreclamation(a1);
l=0;
z=0;

windowmodif=lookup_widget(button,"window_modification");
gtk_widget_destroy(windowmodif);
windowaffich=create_fenetre_afficher();
gtk_widget_show (windowaffich);
}


void
on_button2_rrmod_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowaffich;
windowaffich=create_fenetre_afficher();
gtk_widget_show (windowaffich);
}


void
on_button3_cher_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
char identir[20];
GtkWidget *idenr, *rech,*o, *n;
GtkWidget *tree;
GtkWidget *windowrechercher;

int ce;
windowrechercher=lookup_widget(button,"window_chercher");
o=create_window_affchercher();
n=create_window_non();
idenr = lookup_widget(button,"entry4_cherr");
strcpy(identir,gtk_entry_get_text(GTK_ENTRY(idenr)));
ce=rechercherreclamation(identir);
if (ce==0)
	{
		gtk_widget_show(n);
	}
if (ce==1)	
	{	

gtk_widget_destroy(windowrechercher);

tree=lookup_widget(o,"treeview2");

affichagereclamationrechercher(tree);
gtk_widget_show(o);
}		
}


void
on_button3_rrche_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowaffich;
windowaffich=create_fenetre_afficher();
gtk_widget_show (windowaffich);
}


void
on_button4_rrafch_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowaffich;
windowaffich=create_fenetre_afficher();
gtk_widget_show (windowaffich);
}


void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_button5_rrsup_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowaffich;
windowaffich=create_fenetre_afficher();
gtk_widget_show (windowaffich);
}


void
on_button5_sup_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
char identi[20];
GtkWidget *windowsup, *windowaffich, *iden;
iden = lookup_widget(button,"entry6_suupp");
strcpy(identi,gtk_entry_get_text(GTK_ENTRY(iden)));
supprimerreclamation(identi);

windowsup=lookup_widget(button,"window_sup");
gtk_widget_destroy(windowsup);
windowaffich=create_fenetre_afficher();
gtk_widget_show(windowaffich);
}


void
on_button6_rrnn_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowaffich;
windowaffich=create_fenetre_afficher();
gtk_widget_show (windowaffich);
}


void
on_treeview1_aff_row_activated         (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_button0_aficherr_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *tree,*windowaffich;
windowaffich=lookup_widget(button,"fenetre_afficher");
gtk_widget_destroy(windowaffich);
windowaffich=create_fenetre_afficher();
tree=lookup_widget(windowaffich,"treeview1_aff");

affichagereclamation(tree);

gtk_widget_hide(windowaffich);
gtk_widget_show(windowaffich);
}


void
on_button0_moodd_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowmod;
windowmod=create_window_modification();
gtk_widget_show (windowmod);
}


void
on_button0_rechh_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowrech;
windowrech=create_window_chercher();
gtk_widget_show (windowrech);
}


void
on_button0_plusrec_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowplus;
windowplus=create_window_plus();
gtk_widget_show (windowplus);
}



void
on_act_plusrec_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
int x;
GtkWidget *output;

x=plusreclame();
if (x==1)
{output=lookup_widget(button,"label40");
gtk_label_set_text(GTK_LABEL(output),"le service le plus réclamé est le service de restauration.");
}
else if (x==2)
{output=lookup_widget(button,"label40");
gtk_label_set_text(GTK_LABEL(output),"le service le plus réclamé est le service d'hébergement.");
}
else
{output=lookup_widget(button,"label40");
gtk_label_set_text(GTK_LABEL(output),"les deux services ont été réclamés le meme nombre de fois.");
}



}

