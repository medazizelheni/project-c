#ifdef HAVE_CONFIG_H
#include <config.h>
#endif
#include "recl.h"
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<gtk/gtk.h>

enum
{ 
	EID,
	ENOM,
	ERECLAM,
	ETYPE,
	EJOUR,
	EMOIS,
	EANNEE,
	ECHOIX,
        EETAT,
	COLUMNS,
};



//////////////////////////Fonction Ajouter//////////////////////////
void ajouterreclamation(reclamation a)
{

FILE *f;
f=fopen("Reclamation.txt","a+");

fprintf(f,"%s %s %s %s %d %d %d %s %s \n",a.identifiant,a.nom,a.type,a.choix,a.date.jour,a.date.mois,a.date.annee,a.reclame,a.etat);
fclose(f);
}
//////////////////////////Fonction Supprimer//////////////////////////
void supprimerreclamation(char identifiant [])
{
reclamation a;
FILE *f1;
FILE *f2;

f1=fopen("Reclamation.txt","r");
f2=fopen("recl.txt","w");
while(fscanf(f1,"%s %s %s %s %d %d %d %s %s \n",a.identifiant,a.nom,a.type,a.choix,&a.date.jour,&a.date.mois,&a.date.annee,a.reclame,a.etat)!=EOF)
{if (strcmp(identifiant,a.identifiant)!=0)
fprintf(f2,"%s %s %s %s %d %d %d %s %s \n",a.identifiant,a.nom,a.type,a.choix,a.date.jour,a.date.mois,a.date.annee,a.reclame,a.etat);
}
fclose(f1);
fclose(f2);
remove("Reclamation.txt");
rename("recl.txt","Reclamation.txt");

}
//////////////////////////Fonction Affichage//////////////////////////
void affichagereclamation(GtkWidget *liste)
{
GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	char id[30];
	char nom[30];
	char type[30];
	char choix[30];
	char jour[10];
	char mois[10];
	char annee[10];
	char reclame[30];
	char etat[30];
	store=NULL;
	FILE *f;
	store=gtk_tree_view_get_model (liste);
	if (store==NULL)
	{
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("identifiant", renderer, "text",EID,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("nom", renderer, "text",ENOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("type", renderer, "text",ETYPE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column); 

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("choix", renderer, "text",ECHOIX,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);   

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("jour", renderer, "text",EJOUR,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column); 

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("mois", renderer, "text",EMOIS,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("annee", renderer, "text",EANNEE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("reclame", renderer, "text",ERECLAM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("etat", renderer, "text",EETAT,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	}
	store=gtk_list_store_new (COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,  G_TYPE_STRING,   G_TYPE_STRING, G_TYPE_STRING,  G_TYPE_STRING,  G_TYPE_STRING, G_TYPE_STRING);
	f=fopen("Reclamation.txt","r");
	if(f==NULL)
	{
		return;
	}
	else
	{
		f= fopen("Reclamation.txt","a+");
		while(fscanf(f,"%s %s %s %s %s %s %s %s %s \n",id,nom,type,choix,jour,mois,annee,reclame,etat)!=EOF)
		{
			gtk_list_store_append(store, &iter);
			gtk_list_store_set(store,&iter, EID, id, ENOM, nom, ETYPE, type,  ECHOIX,choix, EJOUR,jour, EMOIS,mois, EANNEE,annee, ERECLAM,reclame, EETAT,etat, -1);
		}
		fclose(f);
		gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
		g_object_unref (store);
	}
}
//////////////////////////Fonction Modifier//////////////////////////                       
void modifierreclamation(reclamation a1)
{
reclamation a;
FILE *f1;
FILE *f2;
f1=fopen("Reclamation.txt","r");
f2=fopen("Reclam.txt","a");

if((f1!=NULL)&&(f2!=NULL))
{
while(fscanf(f1,"%s %s %s %s %d %d %d %s %s \n",a.identifiant,a.nom,a.type,a.choix,&a.date.jour,&a.date.mois,&a.date.annee,a.reclame,a.etat)!=EOF)
	{
	if(strcmp(a.identifiant,a1.identifiant)==0)
		{
		fprintf(f2,"%s %s %s %s %d %d %d %s %s \n",a1.identifiant,a1.nom,a1.type,a1.choix,a1.date.jour,a1.date.mois,a1.date.annee,a1.reclame,a1.etat);
		}
	else
		{
		fprintf(f2,"%s %s %s %s %d %d %d %s %s \n",a.identifiant,a.nom,a.type,a.choix,a.date.jour,a.date.mois,a.date.annee,a.reclame,a.etat);
		}
	}

}
fclose(f1);
fclose(f2);
remove("Reclamation.txt");
rename("Reclam.txt","Reclamation.txt");
}
//////////////////////////Fonction pour remplir un tableau//////////////////////////

int remplirtab (reclamation tab[],int nb)
{
    char id[20],nom[20];
    char type[20],choix[20];		
    char reclam[20],etat[20];
    int jour,mois,annee;
    FILE* fichier ;
    int i;

    fichier = fopen("Reclamation.txt", "a+");


        while (fscanf(fichier,"%s %s %s %s %d %d %d %s %s \n",id,nom,type,choix,&jour,&mois,&annee,reclam,etat)!=EOF)
        {
            
            strcpy(tab[i].identifiant,id);
	    strcpy(tab[i].nom,nom);
            strcpy(tab[i].type,type);
            strcpy(tab[i].choix,choix);
	    tab[i].date.jour=jour;
            tab[i].date.mois=mois;
	    tab[i].date.annee=annee;
            strcpy(tab[i].reclame,reclam);
	    strcpy(tab[i].etat,etat);
            nb++;
	    
        }
        

        fclose(fichier);
	return(nb);
}
//////////////////////////Fonction Rechercher//////////////////////////

int rechercherreclamation(char identifiant[])
{
reclamation tabl[100];
int nb;
int ce,i;
FILE*f;
ce=0;
nb=remplirtab (tabl,nb);
for (i=0;i<nb;i++)
	{if (strcmp(identifiant,tabl[i].identifiant)==0)
		{
		ce=1;
		f=fopen("Reclamationrechercher.txt", "w+");
		if("f!=NULL")
			{fprintf(f,"%s %s %s %s %d %d %d %s %s \n",tabl[i].identifiant,tabl[i].nom,tabl[i].type,tabl[i].choix,tabl[i].date.jour,tabl[i].date.mois,tabl[i].date.annee,tabl[i].reclame,tabl[i].etat);}
		fclose(f);		
		}
	}

return(ce);
}
//////////////////////////Fonction Affichage rechercher//////////////////////////
void affichagereclamationrechercher(GtkWidget *liste)
{
GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	char id[30];
	char nom[30];
	char type[30];
	char choix[30];
	char jour[10];
	char mois[10];
	char annee[10];
	char reclame[30];
	char etat[30];
	store=NULL;
	FILE *f;
	store=gtk_tree_view_get_model (liste);
	if (store==NULL)
	{
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("identifiant", renderer, "text",EID,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("nom", renderer, "text",ENOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("type", renderer, "text",ETYPE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column); 

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("choix", renderer, "text",ECHOIX,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);   

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("jour", renderer, "text",EJOUR,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column); 

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("mois", renderer, "text",EMOIS,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("annee", renderer, "text",EANNEE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("reclame", renderer, "text",ERECLAM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("etat", renderer, "text",EETAT,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	}
	store=gtk_list_store_new (COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,  G_TYPE_STRING,   G_TYPE_STRING, G_TYPE_STRING,  G_TYPE_STRING,  G_TYPE_STRING, G_TYPE_STRING);
	f=fopen("Reclamation.txt","r");
	if(f==NULL)
	{
		return;
	}
	else
	{
		f= fopen("Reclamationrechercher.txt","a+");
		while(fscanf(f,"%s %s %s %s %s %s %s %s %s \n",id,nom,type,choix,jour,mois,annee,reclame,etat)!=EOF)
		{
			gtk_list_store_append(store, &iter);
			gtk_list_store_set(store,&iter, EID, id, ENOM, nom, ETYPE, type,  ECHOIX,choix, EJOUR,jour, EMOIS,mois, EANNEE,annee, ERECLAM,reclame, EETAT,etat, -1);
		}
		fclose(f);
		gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
		g_object_unref (store);
	}
}



//fonction calcul tt les reclamation

int nombre_rec()
{
FILE *f; 
FILE *b; 

f=fopen("reclamation.txt","r") ; 
 

reclamation r ; 
int i=0 ; 
 
	
	char id[30];
	char nom[30];
	char type[30];
	char choix[30];
	char jour[10];
	char mois[10];
	char annee[10];
	char reclame[30];
	char etat[30];

if(f!=NULL) 
{
while(fscanf(f,"%s %s %s %s %s %s %s %s %s \n",id,nom,type,choix,jour,mois,annee,reclame,etat)!=EOF)
{
i+=1;
}
}

return i; 
}



//fonction calcul nbre de rec resto 
int plusreclame()
{
        char resto[20]="Restaurant";
	char id[30];
	char nom[30];
	char type[30];
	char choix[30];
	char jour[10];
	char mois[10];
	char annee[10];
	char reclame[30];
	char etat[30];
int hebergement=0;
int rest=0;
int r;
FILE *f ; 
f=fopen("Reclamation.txt","r"); 



 

if(f!=NULL) 
{
while(fscanf(f,"%s %s %s %s %s %s %s %s %s\n",id,nom,type,choix,jour,mois,annee,reclame,etat)!=EOF)
{if((strcmp(type,resto))==0)

rest++;

else
hebergement++;
}
 
}
fclose(f);
if (rest>hebergement)
r=1;
else if (rest<hebergement)
r=2;
else
r=0;
return r;

}

























