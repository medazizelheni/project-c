#include <gtk/gtk.h>


void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_retour_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_etu_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_enseig_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton1_urg_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button1_ajout_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkbutton1_info_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button1_aff_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_entry2_rraff_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_button0_ajtt_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_button0_supp_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_button0_afff_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton2_etu_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_ens_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2_urg_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2_sip_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button2_mod_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_rrmod_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_button3_cher_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_button3_rrche_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_rrafch_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button5_rrsup_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_button5_sup_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button6_rrnn_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_aff_row_activated         (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button0_aficherr_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button0_moodd_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_button0_rechh_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_button0_plusrec_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_act_plusrec_clicked                 (GtkButton       *button,
                                        gpointer         user_data);
